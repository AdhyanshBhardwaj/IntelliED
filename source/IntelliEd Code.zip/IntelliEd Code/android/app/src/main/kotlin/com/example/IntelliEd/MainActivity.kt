package com.example.IntelliEd

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
